import * as cdk from '@aws-cdk/core';
import * as events from '@aws-cdk/aws-events';
import * as targets from '@aws-cdk/aws-events-targets';
import * as lambda from '@aws-cdk/aws-lambda';
import { Function, Runtime, Code, LayerVersion } from '@aws-cdk/aws-lambda';
import { Stack } from '@aws-cdk/core';

//import * as apigw from '@aws-cdk/aws-apigateway';

export class CdkWorkshopStack extends cdk.Stack {
  constructor(scope: cdk.App, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const layer = new lambda.LayerVersion(this, 'MyLayer', {
      layerVersionName: 'demolayer',
      //code: lambda.Code.fromAsset(path.join(../lambda, 'layer-code')),
      code: Code.fromAsset('lambda'),
      compatibleRuntimes: [lambda.Runtime.PYTHON_3_8],
      license: 'Apache-2.0',
      description: 'A layer to test the L2 construct',
    });

    // defines an AWS Lambda resource
    const hello = new lambda.Function(this, 'HelloHandler', {
      functionName: 'demolambda',
      runtime: lambda.Runtime.PYTHON_3_8,    // execution environment
      code: lambda.Code.fromAsset('lambda'),  // code loaded from "lambda" directory
      //timeout: cdk.Duration.seconds(300),
      handler: 'hello.handler',            // file is "hello", function is "handler"
      layers: [layer],
    
      
    });

  
    const eventRule = new events.Rule(this, 'scheduleRule', {
      schedule: events.Schedule.cron({ minute: '0', hour: '10', weekDay: 'SAT', month: '1-12' }),
    });
    eventRule.addTarget(new targets.LambdaFunction(hello))
  }

  
    // defines an API Gateway REST API resource backed by our "hello" function.
    /*new apigw.LambdaRestApi(this, 'Endpoint', {
      handler: hello
    });
  }*/
}

// export class lambdalayer extends cdk.Stack {
//   constructor(scope: cdk.App, id: string, props?: cdk.StackProps) {
//     super(scope, id, props);


//     const layer = new lambda.LayerVersion(this, 'MyLayer', {
//       //code: lambda.Code.fromAsset(path.join(../lambda, 'layer-code')),
//       code: Code.fromAsset('lambda'),
//       compatibleRuntimes: [lambda.Runtime.PYTHON_3_8],
//       license: 'Apache-2.0',
//       description: 'A layer to test the L2 construct',
//     });

//   }}
